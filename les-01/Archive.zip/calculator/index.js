const { getResult, operator, numbers } = require('./lib');

console.log(getResult(operator, numbers));
