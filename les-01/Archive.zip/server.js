// console.log('Hello, World!');
// console.log(process.env.volodymyr);
// console.log(process.env.ira);
// console.log(process.env.PORT);
// console.log(process.env.NODE_ENV);
// console.log(process.argv);

// require('./calculator');
require('./calculatorOOP');
